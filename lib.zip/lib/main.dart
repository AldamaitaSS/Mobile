import 'package:flutter/material.dart';
// Menambahkan prefix untuk menghindari konflik
import 'dosen/navigasi.dart' as dosenNavigasi;
import 'pimpinan/navigasi.dart' as pimpinanNavigasi;

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sistem Sertifikasi',
      theme: ThemeData(
        fontFamily: 'Poppins', // Set Poppins as the default font
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(), // Your home screen
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0; // Menyimpan indeks tab yang dipilih

  // Daftar widget yang akan ditampilkan pada masing-masing tab
  static List<Widget> _pages = <Widget>[
    dosenNavigasi.Navigasi(),   // Navigasi dari dosen
    pimpinanNavigasi.Navigasi(), // Navigasi dari pimpinan
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index; // Mengubah indeks saat item dipilih
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      body: _pages[_selectedIndex], // Menampilkan halaman sesuai tab yang dipilih
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.school),
            label: 'Dosen',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.business),
            label: 'Pimpinan',
          ),
        ],
        currentIndex: _selectedIndex, // Menunjukkan tab yang aktif
        selectedItemColor: Colors.blue,
        onTap: _onItemTapped, // Menangani pemilihan tab
      ),
    );
  }
}
