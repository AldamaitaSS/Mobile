import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:dio/dio.dart';
import 'upload.dart';
import 'package:file_picker/file_picker.dart';
import '../auth_service.dart';

class CertificationUploadForm extends StatefulWidget {
  final String jenis;
  
  const CertificationUploadForm ({Key? key, required this.jenis}) : super(key: key);

  @override
  _CertificationUploadFormState createState() => _CertificationUploadFormState();
}

class _CertificationUploadFormState extends State<CertificationUploadForm> {
  final Dio _dio = Dio();
  final String baseUrl = 'http://localhost:8000/api';
  final _formKey = GlobalKey<FormState>();
  bool _sedangMemuat = false;
  
  // Data form
  String? _nomorSertifikasi;
  DateTime? _tanggalPelaksanaan;
  DateTime? _tanggalBerlaku;
  String? _namaKegiatan;
  int? _bidangId;  // Ubah menjadi int? karena ini ID yang diharapkan integer
  int? _vendorId;  // Ubah menjadi int? karena ini ID yang diharapkan integer
  String? _namaFile;

  
  // Data dropdown
  List<Map<String, dynamic>> _daftarBidang = [];
  List<Map<String, dynamic>> _daftarVendor = [];

  @override
  void initState() {
    super.initState();
    // Menunda pemanggilan API sampai widget selesai di build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _ambilDataDropdown();
      }
    });
  }

  Future<void> _pilihTanggal(BuildContext context, bool isPelaksanaan) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    if (picked != null && picked != (isPelaksanaan ? _tanggalPelaksanaan : _tanggalBerlaku)) {
      setState(() {
        if (isPelaksanaan) {
          _tanggalPelaksanaan = picked;
        } else {
          _tanggalBerlaku = picked;
        }
      });
    }
  }

  // Mengambil data untuk dropdown bidang dan vendor
  Future<void> _ambilDataDropdown() async {
    if (!mounted) return;

    setState(() => _sedangMemuat = true);

    try {
      final responseBidang = await _dio.get('$baseUrl/bidang');
      final responseVendor = await _dio.get('$baseUrl/vendor');

      if (responseBidang.statusCode == 200 && responseVendor.statusCode == 200) {
        setState(() {
          // Pastikan 'id' dikonversi ke integer dan tampilkan nama
          _daftarBidang = List<Map<String, dynamic>>.from(responseBidang.data['data'].map((e) {
            e['id'] = int.tryParse(e['id'].toString()) ?? 0;
            e['name'] = e['bidang_nama']; // Menampilkan nama bidang
            return e;
          }));

          _daftarVendor = List<Map<String, dynamic>>.from(responseVendor.data['data'].map((e) {
            e['id'] = int.tryParse(e['id'].toString()) ?? 0;
            e['name'] = e['vendor_nama']; // Menampilkan nama vendor
            return e;
          }));

          _sedangMemuat = false;
        });
      } else {
        _tampilkanPesan('Gagal memuat data');
        setState(() => _sedangMemuat = false);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _sedangMemuat = false);
        _tampilkanPesan('Gagal memuat data: $e');
      }
    }
  }

  // Mengirim data form ke server
  Future<void> _kirimForm() async {
    if (!_formKey.currentState!.validate()) return; // Validasi form

    setState(() => _sedangMemuat = true); // Tampilkan loading
    _formKey.currentState!.save(); // Simpan data dari form

    try {
      // Ambil data user login
      final authService = AuthService();
      final userData = await authService.getUserData();
      final userToken = userData['token'];
      final userId = userData['user_id'];

      if (userToken == null || userId == null) {
        throw Exception('Silakan login ulang');
      }

      // Siapkan data untuk dikirim ke server
      final formData = {
        "user_id": userId.toString(),
        "no_sertif": _nomorSertifikasi ?? '',
        "nama_sertif": _namaKegiatan ?? '',
        "tanggal_pelaksanaan": _tanggalPelaksanaan != null
            ? "${_tanggalPelaksanaan!.year}-${_tanggalPelaksanaan!.month}-${_tanggalPelaksanaan!.day}"
            : '',
        "tanggal_berlaku": _tanggalBerlaku != null
            ? "${_tanggalBerlaku!.year}-${_tanggalBerlaku!.month}-${_tanggalBerlaku!.day}"
            : '',
        "bidang_id": _bidangId != null ? _bidangId.toString() : '',
        "vendor_id": _vendorId != null ? _vendorId.toString() : '',
      };

      // Jika ada file yang diunggah, tambahkan ke dalam request
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/uploads'),
      )
        ..headers['Authorization'] = 'Bearer $userToken'
        ..fields.addAll(formData);

      if (_namaFile != null) {
        request.files.add(
          await http.MultipartFile.fromPath('image', _namaFile!),
        );
      }

      // Kirim request ke server
      final response = await request.send();

      if (response.statusCode == 201) {
        // Data berhasil disimpan
        _tampilkanPesan('Data berhasil disimpan!', isError: false);
        _formKey.currentState?.reset(); // Reset form setelah berhasil
        setState(() => _namaFile = null); // Reset file
      } else {
        _tampilkanPesan('Gagal menyimpan data');
      }
    } catch (e) {
      // Jika ada error
      _tampilkanPesan('Terjadi kesalahan: $e');
    } finally {
      setState(() => _sedangMemuat = false); // Sembunyikan loading
    }
  }

  void _tampilkanPesan(String pesan, {bool isError = true}) {
    if (!mounted) return;
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(pesan),
        backgroundColor: isError ? Colors.red : Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Form ${widget.jenis}', 
          style: TextStyle(color: Colors.white)
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        backgroundColor: Color(0xFF1F4C97),
      ),
      body: _sedangMemuat 
        ? Center(child: CircularProgressIndicator())
        : SingleChildScrollView(
            padding: EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _bangunJudulForm(),
                  _bangunInputTeks(
                    'Nomor Sertifikasi',
                    (value) => _nomorSertifikasi = value,
                  ),
                  _bangunInputTanggal(
                    'Tanggal Pelaksanaan',
                    _tanggalPelaksanaan,
                    () => _pilihTanggal(context, true),
                  ),
                  _bangunInputTanggal(
                    'Tanggal Berlaku',
                    _tanggalBerlaku,
                    () => _pilihTanggal(context, false),
                  ),
                  _bangunInputTeks(
                    'Nama Kegiatan',
                    (value) => _namaKegiatan = value,
                  ),
                  _bangunDropdown(
                    'Pilih Bidang',
                    _daftarBidang,
                    (value) => setState(() {
                      _bidangId = int.tryParse(value ?? ''); // Mengonversi String menjadi int
                    }),
                  ),
                  _bangunDropdown(
                    'Pilih Vendor (Opsional)',
                    _daftarVendor,
                    (value) => setState(() {
                      _vendorId = int.tryParse(value ?? ''); // Mengonversi String menjadi int
                    }),
                    wajibDiisi: false,
                  ),
                  _bangunTombolUnggah(),
                  _bangunTombolKirim(),
                ],
              ),
            ),
          ),
    );
  }

  Widget _bangunJudulForm() {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 20),
      child: Center(
        child: Text(
          widget.jenis,
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _bangunInputTeks(String label, Function(String?) onSaved) {
    return Padding(
      padding: EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          TextFormField(
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.grey[200],
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),
            ),
            onSaved: onSaved,
            validator: (value) => 
              value?.isEmpty ?? true ? 'Harap isi field ini' : null,
          ),
        ],
      ),
    );
  }

  Widget _bangunInputTanggal(String label, DateTime? tanggal, Function() onTap) {
    return Padding(
      padding: EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          GestureDetector(
            onTap: onTap,
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 150, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(10),
                
              ),
              child: Text(
                tanggal != null
                    ? "${tanggal.day}-${tanggal.month}-${tanggal.year}" // Format tanggal
                    : 'Pilih Tanggal',
                style: TextStyle(fontSize: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _bangunDropdown(
    String label,
    List<Map<String, dynamic>> opsi,
    Function(String?) onChanged, {
    bool wajibDiisi = true,
  }) {
    return Padding(
      padding: EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          DropdownButtonFormField<String>(
            items: opsi.map((item) {
              return DropdownMenuItem<String>(
                value: item['id'].toString(), // Mengirimkan ID
                child: Text(item['name']), // Menampilkan Nama
              );
            }).toList(),
            onChanged: onChanged,
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.grey[200],
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),
            ),
            validator: wajibDiisi
              ? (value) => value == null ? 'Harap pilih salah satu' : null
              : null,
          ),
        ],
      ),
    );
  }

  Widget _bangunTombolUnggah() {
    return Padding(
      padding: EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Unggah Berkas',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8),
          ElevatedButton.icon(
            icon: Icon(Icons.cloud_upload, color: Colors.white),
            label: Text('Tambah Berkas', style: TextStyle(color: Colors.white)),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => UploadScreen(
                  onFileUploaded: (String fileName) => 
                    setState(() => _namaFile = fileName),
                ),
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: Color(0xFF1F4C97),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          SizedBox(height: 10),
          Text(
            _namaFile != null 
              ? 'File terpilih: $_namaFile'
              : 'Belum ada file yang dipilih',
            style: TextStyle(
              fontSize: 16,
              color: _namaFile == null ? Colors.red : Colors.black,
            ),
          ),
        ],
      ),
    );
  }

  Widget _bangunTombolKirim() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: _sedangMemuat ? null : _kirimForm,
        child: Text(
          _sedangMemuat ? 'Menyimpan...' : 'Simpan',
          style: TextStyle(color: Colors.white),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: Color(0xFF1F4C97),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          padding: EdgeInsets.symmetric(vertical: 16),
        ),
      ),
    );
  }
}